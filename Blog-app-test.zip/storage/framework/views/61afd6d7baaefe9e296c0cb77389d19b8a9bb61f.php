<div class="container mb-4">
    <div class="row">
        <p>
            By: <a href="<?php echo e(route('user.posts',$post->user)); ?>"><?php echo e($post->user->name); ?></a>
             - <span><?php echo e($post->created_at->diffForHumans()); ?></span>
        </p>
        <p>
            <?php echo e($post->body); ?>

        </p>
    </div>
    <div class="row">
        <?php if(auth()->guard()->check()): ?>
            <?php if(!$post->likedBy(auth()->user())): ?>
                <form action="<?php echo e(route('posts.like', $post)); ?>" method="post" class="from">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <button type="submit" class="btn btn-sm btn-success m-2 my-sm-0">Like</button>
                    </div>
                </form>
            <?php else: ?>
                <form action="<?php echo e(route('posts.like', $post)); ?>" method="post" class="form">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <div class="form-group">
                        <button type="submit" class="btn btn-sm btn-warning m-2 my-sm-0">Unlike</button>
                    </div>
                </form>
            <?php endif; ?>
            <?php if($post->ownedBy(auth()->user())): ?>
                <form action="<?php echo e(route('posts.destroy', $post)); ?>" method="post" class="form">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <div class="form-group">
                        <button type="submit" class="btn btn-sm btn-danger m-2 my-sm-0">Delete</button>
                    </div>
                </form>
            <?php endif; ?>
        <?php endif; ?>
        <span class="py-auto"><?php echo e($post->likes->count()); ?> <?php echo e(Str::plural('like', $post->likes->count())); ?></span>
    </div>
</div>
<?php /**PATH /home/krisi/Coding/php_laravel/example-app/resources/views/inc/posts.blade.php ENDPATH**/ ?>