<?php $__env->startSection('content'); ?>
    <div class="jumbotron text-center mt-3">
        <h1><?php echo e($user->name); ?></h1>
        <p>Posted <?php echo e($posts->count()); ?> <?php echo e(Str::plural('time',$posts->count())); ?>

        and has received <?php echo e($user->receivedLikes->count()); ?>

        <?php echo e(Str::plural('like', $user->receivedLikes->count())); ?>.</p>
    </div>
    <?php if($posts->count()): ?>
        <div class="jumbotron text-left mt-3">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('inc.posts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <div class="row">
        <?php echo e($posts->links()); ?>

    </div>
    <?php else: ?>
        <p class="text-center"><?php echo e($user->name); ?> has no posts.</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/krisi/Coding/php_laravel/example-app/resources/views/users/posts/index.blade.php ENDPATH**/ ?>