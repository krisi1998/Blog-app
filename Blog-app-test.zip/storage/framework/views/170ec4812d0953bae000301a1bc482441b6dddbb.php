<?php $__env->startSection('content'); ?>
    <div class="jumbotron text-center mt-3">
        <h1>Wellcome to <?php echo e(env('APP_NAME')); ?></h1>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit,
            sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
        </p>
        <?php if(auth()->guard()->guest()): ?>
            <p>
                <a class="btn btn-lg btn-primary" href="<?php echo e(route('login')); ?>">Login</a>
                <a class="btn btn-lg btn-success" href="<?php echo e(route('register')); ?>">Register</a>
            </p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/krisi/Coding/php_laravel/example-app/resources/views/pages/index.blade.php ENDPATH**/ ?>