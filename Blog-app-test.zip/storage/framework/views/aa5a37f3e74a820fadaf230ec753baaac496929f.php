<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(auth()->guard()->guest()): ?>
            <div class="jumbotron text-center mt-3">
                <h4>Sign in or Register to post.</h4>
                <p>
                    <a class="btn btn-lg btn-primary" href="<?php echo e(route('login')); ?>">Login</a>
                    <a class="btn btn-lg btn-success" href="<?php echo e(route('register')); ?>">Register</a>
                </p>
            </div>
        <?php endif; ?>
        <?php if(auth()->guard()->check()): ?>
            <div class="jumbotron text-center mt-3 p-4">
                <form action="<?php echo e(route('posts')); ?>" method="post" class="form">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="body">New post</label>
                        <textarea name="body" id="body" cols="30" rows="4"
                        class="form-control <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        placeholder="Post something!"></textarea>
                    </div>

                    <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <button type="submit" class="btnSubmit">Post</button>
                </form>
            </div>
        <?php endif; ?>
        <?php if($posts->count()): ?>
            <div class="jumbotron text-left mt-3">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('inc.posts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="row">
                <?php echo e($posts->links()); ?>

            </div>
        <?php else: ?>
            <p class="text-center">There are no posts.</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/krisi/Coding/php_laravel/example-app/resources/views/pages/posts.blade.php ENDPATH**/ ?>