@extends('layouts.app')

@section('content')
    <div class="jumbotron text-center mt-3">
        <h1>About page</h1>
        <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit,
            sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            Praesent tristique magna sit amet. Egestas sed tempus urna et.
            Etiam tempor orci eu lobortis elementum nibh tellus.
            Sagittis id consectetur purus ut.
            Cursus mattis molestie a iaculis at erat pellentesque adipiscing commodo.
            Mattis enim ut tellus elementum sagittis vitae.
            Eget nulla facilisi etiam dignissim diam quis.
            Nulla facilisi morbi tempus iaculis urna id volutpat lacus.
            Suspendisse potenti nullam ac tortor vitae purus.
            Laoreet id donec ultrices tincidunt arcu non sodales.
            Quis ipsum suspendisse ultrices gravida dictum fusce ut placerat.
            Dolor sed viverra ipsum nunc aliquet bibendum enim.
            Elit at imperdiet dui accumsan sit amet.
            Pellentesque massa placerat duis ultricies lacus sed turpis tincidunt.
            Euismod in pellentesque massa placerat duis ultricies lacus sed turpis.
            Pharetra sit amet aliquam id diam maecenas ultricies mi eget.
        </p>
        <p>
            Sed odio morbi quis commodo.
            Neque laoreet suspendisse interdum consectetur libero id faucibus nisl tincidunt.
            Nisl nunc mi ipsum faucibus vitae aliquet nec ullamcorper sit.
            Elementum nibh tellus molestie nunc non blandit massa.
            Id leo in vitae turpis massa sed.
            Pretium vulputate sapien nec sagittis aliquam malesuada.
            Porttitor leo a diam sollicitudin tempor id eu nisl nunc.
            Lobortis scelerisque fermentum dui faucibus in ornare.
            Viverra nibh cras pulvinar mattis nunc.
            Placerat in egestas erat imperdiet.
            Nunc consequat interdum varius sit amet mattis vulputate.
            Lectus nulla at volutpat diam ut venenatis tellus in metus.
            Nulla porttitor massa id neque aliquam vestibulum morbi blandit.
        </p>
    </div>
@endsection
